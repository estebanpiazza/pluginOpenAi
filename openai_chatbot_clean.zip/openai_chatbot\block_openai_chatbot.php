<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

class block_openai_chatbot extends block_base {
    
    public function init() {
        $this->title = get_string('pluginname', 'block_openai_chatbot');
    }
    
    public function get_content() {
        if ($this->content !== null) {
            return $this->content;
        }
        
        $this->content = new stdClass();
        $this->content->text = 'OpenAI ChatBot Block';
        $this->content->footer = '';
        
        return $this->content;
    }
}