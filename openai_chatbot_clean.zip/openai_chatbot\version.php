<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_openai_chatbot';
$plugin->version = 2025100100;
$plugin->requires = 2022112800;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0.0';