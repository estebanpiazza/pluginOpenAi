<?php
// This file is part of Moodle - http://moodle.org/

$string['pluginname'] = 'OpenAI ChatBot';